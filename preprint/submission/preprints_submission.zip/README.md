Preprints.org submission archive
================================

This archive contains the LaTeX source of

    The Protocol Is the Result: How Evaluation Choices Flip the Verdict on
    Lightweight Image Restoration

and everything needed to rebuild it.

Contents
--------
  main.tex                     the manuscript
  refs.bib                     27 references (BibTeX)
  figures/                     the two figures included by the manuscript
  tables/                      the tables included by \input
  README.md                    this file

How to build
------------
    pdflatex main
    bibtex main
    pdflatex main
    pdflatex main

(The manuscript is set two-column; the PDF is main.pdf.)

Notes
-----
* The graphical abstract is submitted separately, as required by the
  platform's instructions: it must be a JPG or PNG and may not be a
  screenshot of the textual abstract.
* The per-image values behind every reported protocol cell are released
  in the accompanying repository under results/per_image/, with the
  aggregated matrix and the scripts that regenerate the tables.
